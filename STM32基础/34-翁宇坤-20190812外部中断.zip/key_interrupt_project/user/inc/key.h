#ifndef KEY_H_
#define KEY_H_
#include "stm32f4xx.h"
void key_init(void);

#endif
