#ifndef DELAY_H_
#define DELAY_H_
#include "stm32f4xx.h"
void delay(u16 time);
#endif
