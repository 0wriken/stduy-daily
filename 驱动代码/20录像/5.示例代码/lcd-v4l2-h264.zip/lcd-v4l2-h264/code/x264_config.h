#define X264_GPL           1
#define X264_INTERLACED    1
#define X264_BIT_DEPTH     0
#define X264_CHROMA_FORMAT 0
#define X264_VERSION ""
#define X264_POINTVER "0.155.x"
